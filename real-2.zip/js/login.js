const cheackValue = () =>{
  let id = document.getElementById("U_id").value;
  let pass = document.getElementById("U_pass").value;
  
  if(id === ""){
         
  }
}


