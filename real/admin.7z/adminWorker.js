/*
//나중에 만듬
console.log("연결확인");
//get id
let workerName=document.getElementById('woker-name');

workerName.addEventListener('click',checkName);

function checkName(){
  if(workerName.value.length <= 2 || workerName.value.length > 5){
    alert("이름은 2자리 이상 5자리 이하로 입력해 주세요");
    workerName.focus();
  }
}
*/
/*
let workerName = document.getElementById('worker-name');
workerName.addEventListener('mouseout',function(e){
  let nameCheck = e.target;

  if(nameCheck !== null){
    if(workerName.length < 2 || workerName.length >5){
      alert('이름을 2~5자리만 입력가능합니다');
  }
  }
})*/